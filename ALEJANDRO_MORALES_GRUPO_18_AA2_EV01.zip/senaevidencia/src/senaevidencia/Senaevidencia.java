/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package senaevidencia;

/**
 *
 * @author Acer
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Senaevidencia {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        String url = "jdbc:mysql://localhost:3307/senaprueba";
        String user = "root";
        String password = "";

        Connection conexion = null;
        Statement statement = null;

        try {
           
            conexion = DriverManager.getConnection(url, user, password);
            System.out.println("conexion correcta con base de los datos ");

            statement = conexion.createStatement();

            // aqui hago las consultas
            String selectQuery = "SELECT * FROM ejercicio";
            ResultSet resultSet = statement.executeQuery(selectQuery);
            System.out.println("Ejerciio de la consulta:");
            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                int numero = resultSet.getInt("numero");
                System.out.println("Nombre: " + nombre + ", Apellido: " + apellido + ", Nmero: " + numero);
            }

            // aqui hago la insercion
            String insertQuery = "INSERT INTO ejercicio (nombre, apellido, numero) VALUES ('Juan', 'Perez', 123)";
            int rowsInserted = statement.executeUpdate(insertQuery);
            if (rowsInserted > 0) {
                System.out.println("Inserción exitosa.");
            }

            // aqui hago la eliminacion
            String deleteQuery = "DELETE FROM ejercicio WHERE nombre='Juan' AND apellido='Perez'";
            int rowsDeleted = statement.executeUpdate(deleteQuery);
            if (rowsDeleted > 0) {
                System.out.println("Eliminacion exitosa.");
            }

            // aqui actualizo un dato
            String updateQuery = "UPDATE ejercicio SET numero=456 WHERE nombre='Juan' AND apellido='Perez'";
            int rowsUpdated = statement.executeUpdate(updateQuery);
            if (rowsUpdated > 0) {
                System.out.println("Actualizacion exitosa.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al conectar a la base de datos.");
        } finally {
            // Cerrar el statement y la conexión
            try {
                if (statement != null) {
                    statement.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}